package com.example.kanmeitu.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kanmeitu.MainActivity;
import com.example.kanmeitu.R;
import com.example.kanmeitu.util.Constant;
import com.example.kanmeitu.util.PreferencesUtil;
import com.example.kanmeitu.util.RegularUtil;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText usernameView;
    private EditText passwordView;
    private Button primaryView;
    private PreferencesUtil sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //找控件
        usernameView = findViewById(R.id.username);
        passwordView = findViewById(R.id.password);
        primaryView = findViewById(R.id.primary);
        primaryView.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        //一、获取用户名
        String phone = usernameView.getText().toString().trim();
        //判断不能为空
        if (TextUtils.isEmpty(phone)) {
            Toast.makeText(this, R.string.hint_enter_username, Toast.LENGTH_SHORT).show();
            return;
        }
        //判断是否为手机号,采用正则表达式
        if (!RegularUtil.isPhone(phone)) {
            Toast.makeText(this, R.string.error_username_format, Toast.LENGTH_SHORT).show();
            return;
        }

        //二、获取密码
        String password = passwordView.getText().toString().trim();
        //判断不能为空
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this,
                    R.string.hint_enter_password,
                    Toast.LENGTH_SHORT).show();
            return;
        }
        //判断密码长度
        if (password.length() < 6 || password.length() > 15) {
            Toast.makeText(this,
                    R.string.error_password_format,
                    Toast.LENGTH_SHORT).show();
            return;
        }
        //本地设置一个假的手机号和密码
        if (Constant.PHONE.equals(phone) && Constant.PASSWORD.equals(password)) {
            //若已经登录过了,就不需要再次登录了,所以增加一个标记
            sp = PreferencesUtil.getInstance(this);
            sp.setLogin(true);

            //关闭当前页面
            finish();
            //跳转到主页面
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this,
                    R.string.error_username_or_password_format,
                    Toast.LENGTH_SHORT).show();
        }
    }
}