package com.example.kanmeitu.util;

public class RegularUtil {
    public final static String PHONE_PATTERN ="^(13[0-9]|15[012356789]|17[013678]|18[0-9]|14[57]|19[89]|166)[0-9]{8}";
    /**
     * 正则表达式匹配判断
     * @param input 需要做匹配操作的字符串
     * @return true是手机号,false不是手机号
     */
    public static boolean isPhone(String input) {
        return input.matches(PHONE_PATTERN);
    }
}
