package com.example.kanmeitu.util;

public class Constant {

    public static final String PHONE = "13311112222";
    public static final String PASSWORD = "abcd1234";
}
