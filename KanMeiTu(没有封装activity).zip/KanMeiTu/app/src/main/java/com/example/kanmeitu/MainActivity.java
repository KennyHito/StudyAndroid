package com.example.kanmeitu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.kanmeitu.activity.LoginActivity;
import com.example.kanmeitu.util.PreferencesUtil;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private PreferencesUtil sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button layoutButton = findViewById(R.id.layout);
        layoutButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        sp = PreferencesUtil.getInstance(this);
        sp.setLogin(false);

        //跳转到登录页面
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);

        //关闭当前页面
        finish();
    }
}