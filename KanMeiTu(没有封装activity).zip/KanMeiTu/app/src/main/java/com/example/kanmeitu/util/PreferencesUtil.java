package com.example.kanmeitu.util;

import android.content.Context;
import android.content.SharedPreferences;

/*
 * 偏好工具类
 * */
public class PreferencesUtil {
    private static final String KEY_LOGIN = "login";
    //单例
    public static PreferencesUtil instance;
    private final Context context;
    private final SharedPreferences preferences;

    public PreferencesUtil(Context context) {
        this.context = context;
        preferences = context.getSharedPreferences("hello", Context.MODE_PRIVATE);
    }

    public static PreferencesUtil getInstance(Context context) {
        if (instance == null) {
            instance = new PreferencesUtil(context.getApplicationContext());
        }
        return instance;
    }

    //设置是否登录
    public void setLogin(Boolean data) {
        preferences.edit().putBoolean(KEY_LOGIN, data).commit();
    }

    //判断是否登录
    public boolean isLogin(){
        return preferences.getBoolean(KEY_LOGIN,false);
    }

}
