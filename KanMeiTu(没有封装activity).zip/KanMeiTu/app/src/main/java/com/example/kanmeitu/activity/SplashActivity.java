package com.example.kanmeitu.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import com.example.kanmeitu.MainActivity;
import com.example.kanmeitu.R;
import com.example.kanmeitu.util.PreferencesUtil;
import com.qmuiteam.qmui.util.QMUIStatusBarHelper;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //原生去掉状态栏,兼容性不好需要使用三方的,腾讯的
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        QMUIStatusBarHelper.translucent(this);
        QMUIStatusBarHelper.setStatusBarLightMode(this);

        findViewById(R.id.copyright).postDelayed(new Runnable() {
            @Override
            public void run() {
             next();
            }
        },3000);

    }

    private void next(){
        //关闭当前页面
        finish();
        PreferencesUtil sp = PreferencesUtil.getInstance(this);
        Intent intent;
        if (sp.isLogin()){
            //跳转到主页面
            intent = new Intent(this, MainActivity.class);
        }else {
            //跳转到登录页面
            intent = new Intent(this, LoginActivity.class);
        }
        startActivity(intent);
    }
}